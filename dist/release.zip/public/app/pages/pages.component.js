System.register(['@angular/core', '@angular/router', '../shared/services/page.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, page_service_1;
    var PagesComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (page_service_1_1) {
                page_service_1 = page_service_1_1;
            }],
        execute: function() {
            PagesComponent = (function () {
                function PagesComponent(_pageService, _router) {
                    this._pageService = _pageService;
                    this._router = _router;
                    this.addVisible = false;
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.settingsVisible = false;
                }
                /**
                 * Init pages
                 *
                 */
                PagesComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.addVisible = false;
                    this.removeVisible = false;
                    this.settingsVisible = false;
                    this.drawerVisible = false;
                    this.page = {};
                    this.pages = [];
                    this.list();
                };
                /**
                 * Updates the list
                 */
                PagesComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._pageService.list()
                        .subscribe(function (data) { _this.pages = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets an modal booleans
                 */
                PagesComponent.prototype.reset = function () {
                    this.removeVisible = false;
                    this.addVisible = false;
                    this.settingsVisible = false;
                    this.drawerVisible = false;
                    this.page = {};
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {Page} page
                 */
                PagesComponent.prototype.setActive = function (page) {
                    this.selectedPage = page;
                };
                /**
                 * Shows the drawer
                 */
                PagesComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the add dialog
                 */
                PagesComponent.prototype.showAdd = function () {
                    this.addVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {Page} page
                 */
                PagesComponent.prototype.showRemove = function (page) {
                    this.removeVisible = true;
                    this.page = page;
                };
                /**
                 * Shows the settings dialog
                 *
                 * @param {Page} page
                 */
                PagesComponent.prototype.showSettings = function (page) {
                    this.settingsVisible = true;
                    this.page = page;
                };
                /**
                 * Shows the settings dialog
                 *
                 * @param {Page} page
                 */
                PagesComponent.prototype.edit = function (page) {
                    // window.location = '/edit?q=' + this.id + '/' + page.url;
                    localStorage.setItem('respond.pageUrl', page.url);
                    this._router.navigate(['/edit']);
                };
                /**
                 * handles error
                 */
                PagesComponent.prototype.failure = function (obj) {
                    console.log(obj);
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                PagesComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-pages',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Pages' | translate }}</h1>      <button class=\"app-add\" (click)=\"showAdd()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z\"></path></g></svg></button>  </menu>  <section class=\"app-main\">    <div id=\"pages-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let page of pages\" (click)=\"setActive(page)\" [class.selected]=\"page === selectedPage\" [class.image]=\"page.thumb !== ''\">       <h2><span class=\"primary\">{{ page.title }}</span><span class=\"secondary\">{{ page.lastModifiedDate | timeAgo }}</span></h2>       <img *ngIf=\"page.thumb !== ''\" class=\"image\" src=\"sites/{{id}}/{{page.thumb}}\">       <small>/{{ page.url }}</small>       <p>{{ page.description }}</p>       <div class=\"app-list-actions\">           <a (click)=\"showRemove(page)\">{{'Remove' | translate }}</a>           <a (click)=\"showSettings(page)\">{{'Settings' | translate }}</a>           <a class=\"primary\" (click)=\"edit(page)\">{{'Edit' | translate }}</a>       </div>     </div>   </div>      <p class=\"no-list-items\" *ngIf=\"pages.length === 0\">{{ 'Nothing here yet' | translate }}</p>  </section>  <respond-add-page [visible]=\"addVisible\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-page>  <respond-page-settings [visible]=\"settingsVisible\" [page]=\"page\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-page-settings>  <respond-remove-page [visible]=\"removeVisible\" [page]=\"page\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-page>  <respond-drawer active=\"pages\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>",
                        providers: [page_service_1.PageService]
                    }), 
                    __metadata('design:paramtypes', [page_service_1.PageService, router_1.Router])
                ], PagesComponent);
                return PagesComponent;
            }());
            exports_1("PagesComponent", PagesComponent);
        }
    }
});

//# sourceMappingURL=pages.component.js.map
