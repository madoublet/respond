System.register(['@angular/core', '@angular/router', '../shared/services/submission.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, submission_service_1;
    var SubmissionsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (submission_service_1_1) {
                submission_service_1 = submission_service_1_1;
            }],
        execute: function() {
            SubmissionsComponent = (function () {
                function SubmissionsComponent(_submissionService, _router) {
                    this._submissionService = _submissionService;
                    this._router = _router;
                }
                /**
                 * Init submissions
                 *
                 */
                SubmissionsComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.submission = {};
                    this.submissions = [];
                    this.list();
                };
                /**
                 * Updates the list
                 */
                SubmissionsComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._submissionService.list()
                        .subscribe(function (data) { _this.submissions = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets an modal booleans
                 */
                SubmissionsComponent.prototype.reset = function () {
                    this.removeVisible = false;
                    this.viewVisible = false;
                    this.drawerVisible = false;
                    this.submission = {};
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {Submission} submission
                 */
                SubmissionsComponent.prototype.setActive = function (submission) {
                    this.selectedSubmission = submission;
                };
                /**
                 * Shows the drawer
                 */
                SubmissionsComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the view dialog
                 *
                 * @param {Submission} submission
                 */
                SubmissionsComponent.prototype.showView = function (submission) {
                    this.viewVisible = true;
                    this.submission = submission;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {Submission} submission
                 */
                SubmissionsComponent.prototype.showRemove = function (submission) {
                    this.removeVisible = true;
                    this.submission = submission;
                };
                /**
                 * handles error
                 */
                SubmissionsComponent.prototype.failure = function (obj) {
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                SubmissionsComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-submissions',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Submissions' | translate }}</h1>  </menu>  <section class=\"app-main\">    <div id=\"submissions-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let submission of submissions\" (click)=\"setActive(submission)\" [class.selected]=\"submission === selectedSubmission\">       <h2><span class=\"primary\">{{ submission.name }}</span><span class=\"secondary\">{{ submission.date | timeAgo }}</span></h2>       <small>{{ submission.formId }}</small>       <div class=\"app-list-actions\">           <a (click)=\"showRemove(submission)\">Remove</a>           <a (click)=\"showView(submission)\" class=\"primary\">View</a>       </div>     </div>   </div>      <p class=\"no-list-items\" *ngIf=\"submissions.length === 0\">{{ 'Nothing here yet' | translate }}</p>  </section>  <respond-view-submission [visible]=\"viewVisible\" [submission]=\"submission\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-view-submission> <respond-remove-submission [visible]=\"removeVisible\" [submission]=\"submission\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-submission>  <respond-drawer active=\"submissions\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>",
                        providers: [submission_service_1.SubmissionService]
                    }), 
                    __metadata('design:paramtypes', [submission_service_1.SubmissionService, router_1.Router])
                ], SubmissionsComponent);
                return SubmissionsComponent;
            }());
            exports_1("SubmissionsComponent", SubmissionsComponent);
        }
    }
});

//# sourceMappingURL=submissions.component.js.map
