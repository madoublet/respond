System.register(['@angular/core', '@angular/router', '../shared/services/code.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, code_service_1;
    var CodeComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (code_service_1_1) {
                code_service_1 = code_service_1_1;
            }],
        execute: function() {
            CodeComponent = (function () {
                function CodeComponent(_route, _router, _codeService) {
                    this._route = _route;
                    this._router = _router;
                    this._codeService = _codeService;
                    this.codeType = 'not-specified';
                }
                /**
                 * init
                 */
                CodeComponent.prototype.ngOnInit = function () {
                    var id, codeUrl;
                    id = localStorage.getItem('respond.siteId');
                    this.codeUrl = localStorage.getItem('respond.codeUrl');
                    this.codeType = localStorage.getItem('respond.codeType');
                    // get types
                    this.pages = [];
                    this.templates = [];
                    this.stylesheets = [];
                    this.scripts = [];
                    this.plugins = [];
                    // set expanded
                    this.isPagesExpanded = false;
                    this.isTemplatesExpanded = false;
                    this.isStylesheetsExpanded = false;
                    this.isScriptsExpanded = false;
                    this.isPluginsExpanded = false;
                    this.retrieve();
                    this.list();
                    this.setExpanded();
                };
                /**
                 * determines which area is expanded by default
                 */
                CodeComponent.prototype.setExpanded = function () {
                    if (this.codeType == 'page') {
                        this.isPagesExpanded = true;
                    }
                    else if (this.codeType == 'template') {
                        this.isTemplatesExpanded = true;
                    }
                    else if (this.codeType == 'stylesheet') {
                        this.isStylesheetsExpanded = true;
                    }
                    else if (this.codeType == 'script') {
                        this.isScriptsExpanded = true;
                    }
                    else if (this.codeType == 'plugin') {
                        this.isPluginsExpanded = true;
                    }
                };
                /**
                * determines which area is expanded by default
                */
                CodeComponent.prototype.expand = function (codeType) {
                    if (codeType == 'page') {
                        this.isPagesExpanded = !this.isPagesExpanded;
                    }
                    else if (codeType == 'template') {
                        this.isTemplatesExpanded = !this.isTemplatesExpanded;
                    }
                    else if (codeType == 'stylesheet') {
                        this.isStylesheetsExpanded = !this.isStylesheetsExpanded;
                    }
                    else if (codeType == 'script') {
                        this.isScriptsExpanded = !this.isScriptsExpanded;
                    }
                    else if (codeType == 'plugin') {
                        this.isPluginsExpanded = !this.isPluginsExpanded;
                    }
                };
                /**
                 * navigates back
                 */
                CodeComponent.prototype.back = function () {
                    history.go(-1);
                };
                /**
                 * Updates the list
                 */
                CodeComponent.prototype.retrieve = function () {
                    var _this = this;
                    this._codeService.retrieve(this.codeUrl, this.codeType)
                        .subscribe(function (data) { console.log(data); _this.setupEditor(data); }, function (error) { _this.failure(error); });
                };
                /**
                 * Views a code block
                 */
                CodeComponent.prototype.view = function (type, url) {
                    this.codeType = type;
                    this.codeUrl = url;
                    this.retrieve();
                };
                /**
                 * Updates the list
                 */
                CodeComponent.prototype.list = function () {
                    var _this = this;
                    this._codeService.list('page')
                        .subscribe(function (data) { _this.pages = data; }, function (error) { _this.failure(error); });
                    this._codeService.list('template')
                        .subscribe(function (data) { _this.templates = data; }, function (error) { _this.failure(error); });
                    this._codeService.list('stylesheet')
                        .subscribe(function (data) { _this.stylesheets = data; }, function (error) { _this.failure(error); });
                    this._codeService.list('script')
                        .subscribe(function (data) { _this.scripts = data; }, function (error) { _this.failure(error); });
                    this._codeService.list('plugin')
                        .subscribe(function (data) { _this.plugins = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * setup the ace editor
                 */
                CodeComponent.prototype.setupEditor = function (data) {
                    this.editor = ace.edit("editor");
                    if (this.codeType == "page") {
                        this.editor.getSession().setMode("ace/mode/html");
                    }
                    else if (this.codeType == "stylesheet") {
                        this.editor.getSession().setMode("ace/mode/css");
                    }
                    else if (this.codeType == "script") {
                        this.editor.getSession().setMode("ace/mode/javascript");
                    }
                    else if (this.codeType == "plugin") {
                        this.editor.getSession().setMode("ace/mode/php");
                    }
                    else {
                        this.editor.getSession().setMode("ace/mode/html");
                    }
                    this.editor.setValue(data);
                    this.editor.setTheme("ace/theme/chrome");
                    this.editor.blur();
                    this.editor.session.selection.clearSelection();
                };
                /**
                 * handles error
                 */
                CodeComponent.prototype.failure = function (obj) {
                    toast.show('failure');
                    if (obj.status == 401) {
                    }
                };
                /**
                 * Handles a successful save
                 */
                CodeComponent.prototype.success = function () {
                    toast.show('success');
                };
                /**
                 * Save the code
                 */
                CodeComponent.prototype.save = function () {
                    var _this = this;
                    // save code from the editor
                    this._codeService.save(this.editor.getValue(), this.codeUrl, this.codeType)
                        .subscribe(function (data) { _this.success(); }, function (error) { _this.failure(error); });
                };
                /**
                 * Save the code and go back
                 */
                CodeComponent.prototype.saveAndExit = function () {
                    var _this = this;
                    // save code from the editor
                    this._codeService.save(this.editor.getValue(), this.codeUrl, this.codeType)
                        .subscribe(function (data) { _this.success(); history.go(-1); }, function (error) { _this.failure(error); });
                };
                CodeComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-code',
                        template: "<menu class=\"app-interior-menu\">   <button class=\"app-back\" (click)=\"back()\"><svg fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z\"/></svg></button>   <h2>{{codeUrl}}</h2> </menu>  <nav class=\"code-menu\">    <h2 (click)=\"expand('page')\" [class.expanded]=\"isPagesExpanded === true\">     <span>{{ 'Pages' | translate }}</span>     <svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">         <path d=\"M7 10l5 5 5-5z\"/>         <path d=\"M0 0h24v24H0z\" fill=\"none\"/>     </svg>   </h2>    <ul [class.expanded]=\"isPagesExpanded === true\">     <li *ngFor=\"let page of pages\"><a (click)=\"view('page', page)\">{{page}}</a></li>   </ul>    <h2 (click)=\"expand('template')\" [class.expanded]=\"isTemplatesExpanded === true\">     <span>{{ 'Templates' | translate }}</span>     <svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">         <path d=\"M7 10l5 5 5-5z\"/>         <path d=\"M0 0h24v24H0z\" fill=\"none\"/>     </svg>   </h2>    <ul [class.expanded]=\"isTemplatesExpanded === true\">     <li *ngFor=\"let template of templates\"><a (click)=\"view('template', template)\">{{template}}</a></li>   </ul>    <h2 (click)=\"expand('stylesheet')\" [class.expanded]=\"isStylesheetsExpanded === true\">     CSS     <svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">         <path d=\"M7 10l5 5 5-5z\"/>         <path d=\"M0 0h24v24H0z\" fill=\"none\"/>     </svg>   </h2>    <ul [class.expanded]=\"isStylesheetsExpanded === true\">     <li *ngFor=\"let stylesheet of stylesheets\"><a (click)=\"view('stylesheet', stylesheet)\">{{stylesheet}}</a></li>   </ul>    <h2 (click)=\"expand('script')\" [class.expanded]=\"isScriptsExpanded === true\">     JS     <svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">         <path d=\"M7 10l5 5 5-5z\"/>         <path d=\"M0 0h24v24H0z\" fill=\"none\"/>     </svg>   </h2>    <ul [class.expanded]=\"isScriptsExpanded === true\">     <li *ngFor=\"let script of scripts\"><a (click)=\"view('script', script)\">{{script}}</a></li>   </ul>    <h2 (click)=\"expand('plugin')\" [class.expanded]=\"isPluginsExpanded === true\">     <span>{{ 'Plugins' | translate }}</span>     <svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"#000000\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\">         <path d=\"M7 10l5 5 5-5z\"/>         <path d=\"M0 0h24v24H0z\" fill=\"none\"/>     </svg>   </h2>    <ul [class.expanded]=\"isPluginsExpanded === true\">     <li *ngFor=\"let plugin of plugins\"><a (click)=\"view('plugin', plugin)\">{{plugin}}</a></li>   </ul>   </nav>   <div id=\"editor\" class=\"code-editor\"></div>  <menu class=\"app-interior-menu-alternate\">   <button class=\"respond-save\" (click)=\"saveAndExit()\">Save and Exit</button>   <button class=\"respond-save primary\" (click)=\"save()\">Save</button> </menu>",
                        providers: [code_service_1.CodeService],
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, router_1.Router, code_service_1.CodeService])
                ], CodeComponent);
                return CodeComponent;
            }());
            exports_1("CodeComponent", CodeComponent);
        }
    }
});

//# sourceMappingURL=code.component.js.map
