System.register(['@angular/core', '@angular/router', '../shared/services/form.service', '../shared/services/form-field.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, form_service_1, form_field_service_1;
    var FormsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (form_service_1_1) {
                form_service_1 = form_service_1_1;
            },
            function (form_field_service_1_1) {
                form_field_service_1 = form_field_service_1_1;
            }],
        execute: function() {
            FormsComponent = (function () {
                function FormsComponent(_formService, _formFieldService, _router) {
                    this._formService = _formService;
                    this._formFieldService = _formFieldService;
                    this._router = _router;
                }
                /**
                 * Init
                 *
                 */
                FormsComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.addVisible = false;
                    this.editVisible = false;
                    this.removeVisible = false;
                    this.addFieldVisible = false;
                    this.editFieldVisible = false;
                    this.removeFieldVisible = false;
                    this.drawerVisible = false;
                    this.overflowVisible = false;
                    this.forms = [];
                    this.fields = [];
                    this.list();
                };
                /**
                 * Updates the list
                 */
                FormsComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._formService.list()
                        .subscribe(function (data) { _this.forms = data; _this.success(); }, function (error) { _this.failure(error); });
                };
                /**
                 * handles the list successfully updated
                 */
                FormsComponent.prototype.success = function () {
                    var x, flag = false;
                    // check if selected form is set
                    if (this.forms.length > 0 && this.forms != undefined) {
                        if (this.selectedForm !== undefined && this.selectedForm !== null) {
                            for (x = 0; x < this.forms.length; x++) {
                                if (this.forms[x].id === this.selectedForm.id) {
                                    flag = true;
                                }
                            }
                        }
                        // check if id is in array
                        if (flag === false) {
                            this.selectedForm = this.forms[0];
                        }
                    }
                    // update fields
                    if (this.selectedForm !== null) {
                        this.listFields();
                    }
                };
                /**
                 * list fields in the form
                 */
                FormsComponent.prototype.listFields = function () {
                    var _this = this;
                    this._formFieldService.list(this.selectedForm.id)
                        .subscribe(function (data) { _this.fields = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets screen
                 */
                FormsComponent.prototype.reset = function () {
                    this.addVisible = false;
                    this.editVisible = false;
                    this.removeVisible = false;
                    this.addFieldVisible = false;
                    this.editFieldVisible = false;
                    this.removeFieldVisible = false;
                    this.drawerVisible = false;
                    this.overflowVisible = false;
                };
                /**
                 * Sets the form to active
                 *
                 * @param {Form} form
                 */
                FormsComponent.prototype.setActive = function (form) {
                    this.selectedForm = form;
                    this.listFields();
                };
                /**
                 * Sets the list field to active
                 *
                 * @param {FormField} field
                 */
                FormsComponent.prototype.setFieldActive = function (field) {
                    this.selectedField = field;
                    this.selectedIndex = this.fields.indexOf(field);
                };
                /**
                 * Shows the drawer
                 */
                FormsComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the overflow menu
                 */
                FormsComponent.prototype.toggleOverflow = function () {
                    this.overflowVisible = !this.overflowVisible;
                };
                /**
                 * Shows the add dialog
                 */
                FormsComponent.prototype.showAdd = function () {
                    this.addVisible = true;
                };
                /**
                 * Shows the edit dialog
                 */
                FormsComponent.prototype.showEdit = function () {
                    this.editVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {Form} form
                 */
                FormsComponent.prototype.showRemove = function () {
                    this.removeVisible = true;
                };
                /**
                 * Shows the add dialog
                 */
                FormsComponent.prototype.showAddField = function () {
                    this.addFieldVisible = true;
                };
                /**
                 * Shows the edit dialog
                 */
                FormsComponent.prototype.showEditField = function () {
                    this.editFieldVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {FormField} field
                 */
                FormsComponent.prototype.showRemoveField = function (field) {
                    this.removeFieldVisible = true;
                };
                /**
                 * Move the field up
                 *
                 * @param {FormField} field
                 */
                FormsComponent.prototype.moveFieldUp = function (field) {
                    var i = this.fields.indexOf(field);
                    if (i != 0) {
                        this.fields.splice(i, 1);
                        this.fields.splice(i - 1, 0, field);
                    }
                    this.updateOrder();
                };
                /**
                 * Move the field down
                 *
                 * @param {FormField} field
                 */
                FormsComponent.prototype.moveFieldDown = function (field) {
                    var i = this.fields.indexOf(field);
                    if (i != (this.fields.length - 1)) {
                        this.fields.splice(i, 1);
                        this.fields.splice(i + 1, 0, field);
                    }
                    this.updateOrder();
                };
                /**
                 * Updates the order of the field fields
                 *
                 */
                FormsComponent.prototype.updateOrder = function () {
                    var _this = this;
                    this._formFieldService.updateOrder(this.selectedForm.id, this.fields)
                        .subscribe(function (data) { }, function (error) { return _this.errorMessage = error; });
                };
                /**
                 * handles errors
                 */
                FormsComponent.prototype.failure = function (obj) {
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                FormsComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-forms',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\" [class.noborder]=\"forms.length !== 0\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Forms' | translate }}</h1>      <button class=\"app-add position-2\" (click)=\"showAddField()\" *ngIf=\"forms.length !== 0\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z\"></path></g></svg></button>      <button class=\"app-overflow\" (click)=\"toggleOverflow()\" *ngIf=\"selectedForm !== undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z\"/></svg></button>  </menu>  <section class=\"app-main\">    <nav class=\"app-selector\">     <ul>       <li *ngFor=\"let form of forms\" [class.selected]=\"form.id === selectedForm.id\" (click)=\"setActive(form)\">         <a>{{form.name}}</a>       </li>     </ul>   </nav>     <div id=\"fields-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let field of fields\" (click)=\"setFieldActive(field)\" [class.selected]=\"field === selectedField\">       <h2><span class=\"primary\">{{ field.label }}</span></h2>       <small>{{ field.type }}</small>       <div class=\"app-list-actions\">           <span class=\"app-list-alternate-actions\">             <a (click)=\"moveFieldDown(field)\">{{ 'Move Down' | translate }}</a>             <a (click)=\"moveFieldUp(field)\">{{ 'Move Up' | translate }}</a>           </span>           <a (click)=\"showRemoveField(field)\">{{ 'Remove' | translate }}</a>           <a class=\"primary\" (click)=\"showEditField(field)\">{{ 'Edit' | translate }}</a>       </div>     </div>   </div>    <p class=\"no-list-items\" *ngIf=\"fields.length === 0\">     {{ 'Nothing here yet' | translate }}     <a (click)=\"showAddField()\" *ngIf=\"forms.length !== 0 && fields.length === 0\">{{ 'Add Form Field' | translate }}</a>     <a (click)=\"showAdd()\" *ngIf=\"forms.length === 0\">{{ 'Add Form' | translate }}</a>   </p>  </section>  <respond-add-form [visible]=\"addVisible\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-form>  <respond-edit-form [visible]=\"editVisible\" [form]=\"selectedForm\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-edit-form>  <respond-remove-form [visible]=\"removeVisible\" [form]=\"selectedForm\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-form>  <respond-add-form-field [visible]=\"addFieldVisible\" [form]=\"selectedForm\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-form-field>  <respond-edit-form-field [visible]=\"editFieldVisible\" [form]=\"selectedForm\" [field]=\"selectedField\" [index]=\"selectedIndex\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-edit-form-field>  <respond-remove-form-field [visible]=\"removeFieldVisible\" [form]=\"selectedForm\" [field]=\"selectedField\" [index]=\"selectedIndex\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-form-field>  <respond-drawer active=\"forms\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>  <nav class=\"app-overflow\" [class.visible]=\"overflowVisible === true\">    <ul>     <li class=\"app-overflow-title\"><span>{{ 'Additional Options' | translate }}</span></li>     <li><a (click)=\"showAdd()\">{{ 'Add Form' | translate }}</a></li>     <li><a (click)=\"showEdit()\">{{ 'Edit Form' | translate }}</a></li>     <li><a (click)=\"showRemove()\">{{ 'Remove Form' | translate }}</a></li>   </ul>  </nav>",
                        providers: [form_service_1.FormService, form_field_service_1.FormFieldService]
                    }), 
                    __metadata('design:paramtypes', [form_service_1.FormService, form_field_service_1.FormFieldService, router_1.Router])
                ], FormsComponent);
                return FormsComponent;
            }());
            exports_1("FormsComponent", FormsComponent);
        }
    }
});

//# sourceMappingURL=forms.component.js.map
