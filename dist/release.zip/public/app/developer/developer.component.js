System.register(['@angular/core', '@angular/router', '../shared/services/site.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, site_service_1;
    var DeveloperComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (site_service_1_1) {
                site_service_1 = site_service_1_1;
            }],
        execute: function() {
            DeveloperComponent = (function () {
                function DeveloperComponent(_siteService, _router) {
                    this._siteService = _siteService;
                    this._router = _router;
                    this.addVisible = false;
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.settingsVisible = false;
                }
                /**
                 * Init pages
                 *
                 */
                DeveloperComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.settingsVisible = false;
                    this.drawerVisible = false;
                    this.list();
                };
                /**
                 * Updates the list
                 */
                DeveloperComponent.prototype.list = function () {
                    this.reset();
                };
                /**
                 * Resets an modal booleans
                 */
                DeveloperComponent.prototype.reset = function () {
                    this.drawerVisible = false;
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {String} option
                 */
                DeveloperComponent.prototype.setActive = function (option) {
                    this.selectedOption = option;
                };
                /**
                 * Shows the drawer
                 */
                DeveloperComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Reload system files
                 */
                DeveloperComponent.prototype.reload = function () {
                    this._siteService.reload()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * Reindex pages
                 */
                DeveloperComponent.prototype.reindex = function () {
                    this._siteService.reindex()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * Republish site
                 */
                DeveloperComponent.prototype.sitemap = function () {
                    this._siteService.sitemap()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * Migrate R5 site
                 */
                DeveloperComponent.prototype.migrate = function () {
                    this._siteService.migrate()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * Republish Templates
                 */
                DeveloperComponent.prototype.templates = function () {
                    this._siteService.republishTemplates()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * Updates Plugins (re-syncs them with the latest version from the theme)
                 */
                DeveloperComponent.prototype.update = function () {
                    this._siteService.updatePlugins()
                        .subscribe(function (data) { toast.show('success'); }, function (error) { toast.show('failure'); });
                };
                /**
                 * handles error
                 */
                DeveloperComponent.prototype.failure = function (obj) {
                    console.log(obj);
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                DeveloperComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-developer',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Developer Options' | translate }}</h1> </menu>  <section class=\"app-main\">    <div id=\"developer-list\" class=\"app-list\">     <div class=\"app-list-item\" (click)=\"setActive('plugins')\" [class.selected]=\"selectedOption === 'plugins'\">       <h2><span class=\"primary\">{{ 'Re-publish Plugins' | translate }}</span></h2>       <p>{{ 'When you are developing a plugin, you can use this function to republish the pages so the plugin update takes effect.' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"reload()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- plugins -->      <div class=\"app-list-item\" (click)=\"setActive('reindex')\" [class.selected]=\"selectedOption === 'reindex'\">       <h2><span class=\"primary\">{{ 'Re-index Pages' | translate }}</span></h2>       <p>{{ 'Republish the sitemap and pages index.' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"reindex()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- sitemap -->      <div class=\"app-list-item\" (click)=\"setActive('sitemap')\" [class.selected]=\"selectedOption === 'sitemap'\">       <h2><span class=\"primary\">{{ 'Re-publish Sitemap' | translate }}</span></h2>       <p>{{ 'Republish the sitemap when you make changes outside of the application' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"sitemap()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- sitemap -->      <div class=\"app-list-item\" (click)=\"setActive('migrate')\" [class.selected]=\"selectedOption === 'migrate'\">       <h2><span class=\"primary\">{{ 'Migrate Respond 5 site' | translate }}</span></h2>       <p>{{ 'Updates HTML from Respond 5 so that it consistent with Respond 6' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"migrate()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- migrate -->      <div class=\"app-list-item\" (click)=\"setActive('templates')\" [class.selected]=\"selectedOption === 'templates'\">       <h2><span class=\"primary\">{{ 'Republish Templates' | translate }}</span></h2>       <p>{{ 'Republishes all templates and pushes the updates to pages that inherit from those templates.  Warning: Will overwrite any custom HTML outside of the [role=main] block with HTML from the template.' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"templates()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- republish template -->      <div class=\"app-list-item\" (click)=\"setActive('update-plugins')\" [class.selected]=\"selectedOption === 'update-plugins'\">       <h2><span class=\"primary\">{{ 'Update Plugins' | translate }}</span></h2>       <p>{{ 'Updates the plugins for your site and re-syncs them with the latest version from the theme. Warning: will overwrite any custom updates you made to plugins built into the theme.' | translate }}</p>       <div class=\"app-list-actions\">           <a class=\"primary\" (click)=\"update()\">{{'Execute' | translate }}</a>       </div>     </div>     <!-- republish template -->    </div>  </section>  <respond-drawer active=\"pages\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>",
                        providers: [site_service_1.SiteService]
                    }), 
                    __metadata('design:paramtypes', [site_service_1.SiteService, router_1.Router])
                ], DeveloperComponent);
                return DeveloperComponent;
            }());
            exports_1("DeveloperComponent", DeveloperComponent);
        }
    }
});

//# sourceMappingURL=developer.component.js.map
