System.register(['@angular/core', '@angular/router', '../shared/services/component.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, component_service_1;
    var ComponentsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (component_service_1_1) {
                component_service_1 = component_service_1_1;
            }],
        execute: function() {
            ComponentsComponent = (function () {
                function ComponentsComponent(_componentService, _router) {
                    this._componentService = _componentService;
                    this._router = _router;
                    this.addVisible = false;
                    this.removeVisible = false;
                    this.drawerVisible = false;
                }
                /**
                 * Init
                 *
                 */
                ComponentsComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.addVisible = false;
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.component = {};
                    this.components = [];
                    this.list();
                };
                /**
                 * Updates the list
                 */
                ComponentsComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._componentService.list()
                        .subscribe(function (data) { _this.components = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets modal booleans
                 */
                ComponentsComponent.prototype.reset = function () {
                    this.removeVisible = false;
                    this.addVisible = false;
                    this.drawerVisible = false;
                    this.component = {};
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {Any} component
                 */
                ComponentsComponent.prototype.setActive = function (component) {
                    this.selectedComponent = component;
                };
                /**
                 * Shows the drawer
                 */
                ComponentsComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the add dialog
                 */
                ComponentsComponent.prototype.showAdd = function () {
                    this.addVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {Any} component
                 */
                ComponentsComponent.prototype.showRemove = function (component) {
                    this.removeVisible = true;
                    this.component = component;
                };
                /**
                 * Edits a component
                 *
                 * @param {Any} component
                 */
                ComponentsComponent.prototype.edit = function (component) {
                    localStorage.setItem('respond.pageUrl', 'components/' + component.url);
                    localStorage.setItem('respond.editMode', 'component');
                    var id = Math.random().toString(36).substr(2, 9);
                    this._router.navigate(['/edit', id]);
                };
                /**
                 * Edits code for a component
                 *
                 * @param {Any} component
                 */
                ComponentsComponent.prototype.editCode = function (component) {
                    localStorage.setItem('respond.codeUrl', 'components/' + component.url);
                    localStorage.setItem('respond.codeType', 'component');
                    var id = Math.random().toString(36).substr(2, 9);
                    this._router.navigate(['/code', id]);
                };
                /**
                 * handles error
                 */
                ComponentsComponent.prototype.failure = function (obj) {
                    console.log(obj);
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                ComponentsComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-components',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Components' | translate }}</h1>      <button class=\"app-add\" (click)=\"showAdd()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z\"></path></g></svg></button>  </menu>  <section class=\"app-main\">    <div id=\"components-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let component of components\" (click)=\"setActive(component)\" [class.selected]=\"component === selectedComponent\">       <h2>         <span class=\"primary\">{{ component.title }}</span>       </h2>       <small>         {{ component.url }}       </small>       <div class=\"app-list-actions\">           <a (click)=\"showRemove(component)\">{{'Remove' | translate }}</a>           <a (click)=\"editCode(component)\">{{'Edit HTML' | translate }}</a>           <a class=\"primary\" (click)=\"edit(component)\">{{'Edit' | translate }}</a>       </div>     </div>   </div>    <p class=\"no-list-items\" *ngIf=\"components.length === 0\">{{ 'Nothing here yet' | translate }}</p>  </section>  <respond-add-component [visible]=\"addVisible\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-component>  <respond-remove-component [visible]=\"removeVisible\" [component]=\"component\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-component>  <respond-drawer active=\"components\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>",
                        providers: [component_service_1.ComponentService]
                    }), 
                    __metadata('design:paramtypes', [component_service_1.ComponentService, router_1.Router])
                ], ComponentsComponent);
                return ComponentsComponent;
            }());
            exports_1("ComponentsComponent", ComponentsComponent);
        }
    }
});

//# sourceMappingURL=components.component.js.map
