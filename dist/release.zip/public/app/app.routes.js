System.register(['@angular/router', './login/login.component', './forgot/forgot.component', './reset/reset.component', './create/create.component', './pages/pages.component', './files/files.component', './users/users.component', './menus/menus.component', './forms/forms.component', './settings/settings.component', './submissions/submissions.component', './galleries/galleries.component', './edit/edit.component', './developer/developer.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var router_1, login_component_1, forgot_component_1, reset_component_1, create_component_1, pages_component_1, files_component_1, users_component_1, menus_component_1, forms_component_1, settings_component_1, submissions_component_1, galleries_component_1, edit_component_1, developer_component_1;
    var appRoutes, routing;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (login_component_1_1) {
                login_component_1 = login_component_1_1;
            },
            function (forgot_component_1_1) {
                forgot_component_1 = forgot_component_1_1;
            },
            function (reset_component_1_1) {
                reset_component_1 = reset_component_1_1;
            },
            function (create_component_1_1) {
                create_component_1 = create_component_1_1;
            },
            function (pages_component_1_1) {
                pages_component_1 = pages_component_1_1;
            },
            function (files_component_1_1) {
                files_component_1 = files_component_1_1;
            },
            function (users_component_1_1) {
                users_component_1 = users_component_1_1;
            },
            function (menus_component_1_1) {
                menus_component_1 = menus_component_1_1;
            },
            function (forms_component_1_1) {
                forms_component_1 = forms_component_1_1;
            },
            function (settings_component_1_1) {
                settings_component_1 = settings_component_1_1;
            },
            function (submissions_component_1_1) {
                submissions_component_1 = submissions_component_1_1;
            },
            function (galleries_component_1_1) {
                galleries_component_1 = galleries_component_1_1;
            },
            function (edit_component_1_1) {
                edit_component_1 = edit_component_1_1;
            },
            function (developer_component_1_1) {
                developer_component_1 = developer_component_1_1;
            }],
        execute: function() {
            appRoutes = [
                {
                    path: 'login/:id',
                    component: login_component_1.LoginComponent
                },
                {
                    path: 'create',
                    component: create_component_1.CreateComponent
                },
                {
                    path: 'forgot/:id',
                    component: forgot_component_1.ForgotComponent
                },
                {
                    path: 'reset/:id/:token',
                    component: reset_component_1.ResetComponent
                },
                {
                    path: 'pages',
                    component: pages_component_1.PagesComponent
                },
                {
                    path: 'files',
                    component: files_component_1.FilesComponent
                },
                {
                    path: 'users',
                    component: users_component_1.UsersComponent
                },
                {
                    path: 'menus',
                    component: menus_component_1.MenusComponent
                },
                {
                    path: 'forms',
                    component: forms_component_1.FormsComponent
                },
                {
                    path: 'settings',
                    component: settings_component_1.SettingsComponent
                },
                {
                    path: 'submissions',
                    component: submissions_component_1.SubmissionsComponent
                },
                {
                    path: 'galleries',
                    component: galleries_component_1.GalleriesComponent
                },
                {
                    path: 'edit',
                    component: edit_component_1.EditComponent
                },
                {
                    path: 'developer',
                    component: developer_component_1.DeveloperComponent
                },
                {
                    path: '',
                    redirectTo: '/create',
                    pathMatch: 'full'
                }
            ];
            exports_1("routing", routing = router_1.RouterModule.forRoot(appRoutes));
        }
    }
});

//# sourceMappingURL=app.routes.js.map
