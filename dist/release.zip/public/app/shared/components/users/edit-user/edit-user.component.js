System.register(['@angular/core', '../../../../shared/services/user.service', '../../../../shared/services/app.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_service_1, app_service_1;
    var EditUserComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_service_1_1) {
                user_service_1 = user_service_1_1;
            },
            function (app_service_1_1) {
                app_service_1 = app_service_1_1;
            }],
        execute: function() {
            EditUserComponent = (function () {
                function EditUserComponent(_userService, _appService) {
                    this._userService = _userService;
                    this._appService = _appService;
                    this._visible = false;
                    this.onCancel = new core_1.EventEmitter();
                    this.onUpdate = new core_1.EventEmitter();
                    this.onError = new core_1.EventEmitter();
                }
                Object.defineProperty(EditUserComponent.prototype, "visible", {
                    get: function () { return this._visible; },
                    set: function (visible) {
                        // set visible
                        this._visible = visible;
                        // reset model
                        this.model = {
                            email: '',
                            firstName: '',
                            lastName: '',
                            password: '',
                            retype: '',
                            language: 'en'
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(EditUserComponent.prototype, "user", {
                    set: function (user) {
                        // set visible
                        this.model = user;
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * Inits component
                 */
                EditUserComponent.prototype.ngOnInit = function () {
                    this.languages = [];
                    this.list();
                };
                /**
                 * Lists available languages
                 */
                EditUserComponent.prototype.list = function () {
                    var _this = this;
                    this._appService.listLanguages()
                        .subscribe(function (data) { _this.languages = data; }, function (error) { _this.onError.emit(error); });
                };
                /**
                 * Hides the modal
                 */
                EditUserComponent.prototype.hide = function () {
                    this._visible = false;
                    this.onCancel.emit(null);
                };
                /**
                 * Submits the form
                 */
                EditUserComponent.prototype.submit = function () {
                    var _this = this;
                    if (this.model.password != this.model.retype) {
                        console.log('[respond.error] password mismatch');
                        toast.show('failure', 'The password does not match the retype field');
                        return;
                    }
                    // add user
                    this._userService.edit(this.model.email, this.model.firstName, this.model.lastName, this.model.password, this.model.language)
                        .subscribe(function (data) { _this.success(); }, function (error) { _this.onError.emit(error); });
                };
                /**
                 * Handles a successful edit
                 */
                EditUserComponent.prototype.success = function () {
                    toast.show('success');
                    this._visible = false;
                    this.onUpdate.emit(null);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean), 
                    __metadata('design:paramtypes', [Boolean])
                ], EditUserComponent.prototype, "visible", null);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], EditUserComponent.prototype, "user", null);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], EditUserComponent.prototype, "onCancel", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], EditUserComponent.prototype, "onUpdate", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], EditUserComponent.prototype, "onError", void 0);
                EditUserComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-edit-user',
                        moduleId: __moduleName,
                        template: "<div class=\"app-modal\" [class.visible]=\"visible === true\">    <form (ngSubmit)=\"submit()\" #addForm=\"ngForm\">      <h2>{{ 'Edit User' | translate }}</h2>      <div class=\"app-modal-body\">        <label>{{ 'Email' | translate }}</label>       <input id=\"hashedit-edit-user-email\" type=\"text\" maxlength=\"128\" required         [(ngModel)]=\"model.email\"         name=\"email\" disabled=\"disabled\">        <label>{{ 'First Name' | translate }}</label>       <input id=\"hashedit-edit-user-first-name\" type=\"text\" maxlength=\"128\" required         [(ngModel)]=\"model.firstName\"         name=\"firstName\">        <label>{{ 'Last Name' | translate }}</label>       <input id=\"hashedit-edit-user-last-name\" type=\"text\" maxlength=\"128\" required         [(ngModel)]=\"model.lastName\"         name=\"lastName\">        <label>{{ 'Password' | translate }}</label>       <input id=\"hashedit-edit-user-password\" type=\"password\" maxlength=\"128\" required         [(ngModel)]=\"model.password\"         name=\"password\">        <label>{{ 'Retype Password' | translate }}</label>       <input id=\"hashedit-edit-user-retype\" type=\"password\" maxlength=\"128\" required         [(ngModel)]=\"model.retype\"         name=\"retype\">        <label>{{ 'Language' | translate }}</label>       <select id=\"hashedit-edit-user-language\"         [(ngModel)]=\"model.language\"         name=\"language\">         <option *ngFor=\"let language of languages\" [value]=\"language.code\">{{language.text}}</option>       </select>      </div>     <!-- /.app-modal-body -->      <div class=\"actions\">       <a (click)=\"hide()\">{{ 'Cancel' | translate }}</a>       <button type=\"submit\">{{ 'Update' | translate }}</button>     </div>    </form>  </div>",
                        providers: [user_service_1.UserService, app_service_1.AppService]
                    }), 
                    __metadata('design:paramtypes', [user_service_1.UserService, app_service_1.AppService])
                ], EditUserComponent);
                return EditUserComponent;
            }());
            exports_1("EditUserComponent", EditUserComponent);
        }
    }
});

//# sourceMappingURL=edit-user.component.js.map
