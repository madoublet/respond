System.register(['@angular/core', '../../../../shared/services/page.service', '../../../../shared/services/site.service', '../../../../shared/services/route.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, page_service_1, site_service_1, route_service_1;
    var PageSettingsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (page_service_1_1) {
                page_service_1 = page_service_1_1;
            },
            function (site_service_1_1) {
                site_service_1 = site_service_1_1;
            },
            function (route_service_1_1) {
                route_service_1 = route_service_1_1;
            }],
        execute: function() {
            PageSettingsComponent = (function () {
                function PageSettingsComponent(_pageService, _siteService, _routeService) {
                    this._pageService = _pageService;
                    this._siteService = _siteService;
                    this._routeService = _routeService;
                    this._visible = false;
                    this.onCancel = new core_1.EventEmitter();
                    this.onUpdate = new core_1.EventEmitter();
                    this.onError = new core_1.EventEmitter();
                }
                Object.defineProperty(PageSettingsComponent.prototype, "visible", {
                    get: function () { return this._visible; },
                    set: function (visible) {
                        // set visible
                        this._visible = visible;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PageSettingsComponent.prototype, "page", {
                    set: function (page) {
                        // set visible
                        this.model = page;
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * Init pages
                 */
                PageSettingsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this._routeService.list()
                        .subscribe(function (data) { _this.routes = data; }, function (error) { _this.onError.emit(error); });
                    this._siteService.listTemplates()
                        .subscribe(function (data) { _this.templates = data; }, function (error) { _this.onError.emit(error); });
                };
                /**
                 * Hides the modal
                 */
                PageSettingsComponent.prototype.hide = function () {
                    this._visible = false;
                    this.onCancel.emit(null);
                };
                /**
                 * Submits the form
                 */
                PageSettingsComponent.prototype.submit = function () {
                    var _this = this;
                    this._pageService.updateSettings(this.model.url, this.model.title, this.model.description, this.model.keywords, this.model.callout, this.model.language, this.model.direction, this.model.template)
                        .subscribe(function (data) { _this.success(); }, function (error) { _this.errorMessage = error; _this.error(); });
                };
                /**
                 * Handles a successful submission
                 */
                PageSettingsComponent.prototype.success = function () {
                    toast.show('success');
                    this._visible = false;
                    this.onUpdate.emit(null);
                };
                /**
                 * Handles an error
                 */
                PageSettingsComponent.prototype.error = function () {
                    console.log('[respond.error] ' + this.errorMessage);
                    toast.show('failure');
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean), 
                    __metadata('design:paramtypes', [Boolean])
                ], PageSettingsComponent.prototype, "visible", null);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], PageSettingsComponent.prototype, "page", null);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], PageSettingsComponent.prototype, "onCancel", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], PageSettingsComponent.prototype, "onUpdate", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], PageSettingsComponent.prototype, "onError", void 0);
                PageSettingsComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-page-settings',
                        moduleId: __moduleName,
                        template: "<div class=\"app-modal\" [class.visible]=\"visible === true\">    <form (ngSubmit)=\"submit()\" #editForm=\"ngForm\">      <h2>{{ 'Page Settings' | translate }}</h2>      <div class=\"app-modal-body\">        <label>{{ 'Title' | translate }}</label>       <input id=\"hashedit-page-settings-title\" type=\"text\" maxlength=\"128\" required         [(ngModel)]=\"model.title\"         name=\"title\">        <label>{{ 'Description' | translate }}</label>       <input id=\"hashedit-page-settings-description\" type=\"text\" maxlength=\"128\"         [(ngModel)]=\"model.description\"         name=\"description\">        <label>{{ 'Keywords' | translate }}</label>       <input id=\"hashedit-page-settings-keywords\" type=\"text\" maxlength=\"128\"         [(ngModel)]=\"model.keywords\"         name=\"keywords\">        <label>{{ 'Callout' | translate }}</label>       <input id=\"hashedit-page-settings-callout\" type=\"text\" maxlength=\"128\"         [(ngModel)]=\"model.callout\"         name=\"callout\">        <label>{{ 'Language' | translate }}</label>       <select id=\"hashedit-page-settings-language\"         [(ngModel)]=\"model.language\"         name=\"language\">         <option value=\"en\">English (en)</option>         <option value=\"es\">Espa\u00F1ol (es)</option>         <option value=\"fr\">Fran\u00E7ais (fr)</option>         <option value=\"gr\">\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC (gr)</option>         <option value=\"ru\">\u0420\u0443\u0441\u0441\u043A\u0438\u0439 (ru)</option>       </select>        <label>{{ 'Direction' | translate }}</label>       <select id=\"hashedit-page-settings-direction\"         [(ngModel)]=\"model.direction\"         name=\"direction\">         <option value=\"ltr\">{{ 'Left-to-Right' | translate }}</option>         <option value=\"rtl\">{{ 'Right-to-Left' | translate }}</option>       </select>        <label>{{ 'Template' | translate }}</label>       <select id=\"hashedit-add-page-template\"         [(ngModel)]=\"model.template\"         name=\"template\">         <option *ngFor=\"let template of templates\" [value]=\"template\">{{template}}</option>       </select>      </div>     <!-- /.app-modal-body -->      <div class=\"actions\">       <a (click)=\"hide()\">{{ 'Cancel' | translate }}</a>       <button type=\"submit\">{{ 'Update' | translate }}</button>     </div>    </form>  </div>",
                        providers: [page_service_1.PageService, site_service_1.SiteService, route_service_1.RouteService]
                    }), 
                    __metadata('design:paramtypes', [page_service_1.PageService, site_service_1.SiteService, route_service_1.RouteService])
                ], PageSettingsComponent);
                return PageSettingsComponent;
            }());
            exports_1("PageSettingsComponent", PageSettingsComponent);
        }
    }
});

//# sourceMappingURL=page-settings.component.js.map
