System.register(['@angular/core', '../../../../shared/services/file.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, file_service_1;
    var RemoveFileComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (file_service_1_1) {
                file_service_1 = file_service_1_1;
            }],
        execute: function() {
            RemoveFileComponent = (function () {
                function RemoveFileComponent(_fileService) {
                    this._fileService = _fileService;
                    this._visible = false;
                    this.onCancel = new core_1.EventEmitter();
                    this.onUpdate = new core_1.EventEmitter();
                    this.onError = new core_1.EventEmitter();
                }
                Object.defineProperty(RemoveFileComponent.prototype, "visible", {
                    get: function () { return this._visible; },
                    set: function (visible) {
                        // set visible
                        this._visible = visible;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RemoveFileComponent.prototype, "file", {
                    set: function (file) {
                        // set visible
                        this.model = file;
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * Init files
                 */
                RemoveFileComponent.prototype.ngOnInit = function () {
                };
                /**
                 * Hides the modal
                 */
                RemoveFileComponent.prototype.hide = function () {
                    this._visible = false;
                    this.onCancel.emit(null);
                };
                /**
                 * Submits the form
                 */
                RemoveFileComponent.prototype.submit = function () {
                    var _this = this;
                    this._fileService.remove(this.model.name)
                        .subscribe(function (data) { _this.success(); }, function (error) { _this.onError.emit(error); });
                };
                /**
                 * Handles a successful submission
                 */
                RemoveFileComponent.prototype.success = function () {
                    this._visible = false;
                    this.onUpdate.emit(null);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean), 
                    __metadata('design:paramtypes', [Boolean])
                ], RemoveFileComponent.prototype, "visible", null);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RemoveFileComponent.prototype, "file", null);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RemoveFileComponent.prototype, "onCancel", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RemoveFileComponent.prototype, "onUpdate", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RemoveFileComponent.prototype, "onError", void 0);
                RemoveFileComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-remove-file',
                        moduleId: __moduleName,
                        template: "<div class=\"app-modal\" [class.visible]=\"visible === true\">    <form (ngSubmit)=\"submit()\" #removeForm=\"ngForm\">      <h2>{{ 'Remove File' | translate }}</h2>      <p>{{ 'Confirm you want to remove:' | translate }}</p>      <div class=\"to-be-removed\">       <h3>{{model.name}}</h3>       <small>/file/{{model.name}}</small>     </div>      <div class=\"actions\">       <a (click)=\"hide()\">{{ 'Cancel' | translate }}</a>       <button type=\"submit\">{{ 'Remove File' | translate }}</button>     </div>    </form>  </div>",
                        providers: [file_service_1.FileService]
                    }), 
                    __metadata('design:paramtypes', [file_service_1.FileService])
                ], RemoveFileComponent);
                return RemoveFileComponent;
            }());
            exports_1("RemoveFileComponent", RemoveFileComponent);
        }
    }
});

//# sourceMappingURL=remove-file.component.js.map
