System.register(['@angular/core', '@angular/platform-browser', '@angular/forms', '@angular/router', './app.component', './shared/components/drawer/drawer.component', './shared/components/dropzone/dropzone.component', './login/login.component', './forgot/forgot.component', './reset/reset.component', './create/create.component', './developer/developer.component', './code/code.component', './edit/edit.component', './files/files.component', './shared/components/files/remove-file/remove-file.component', './shared/components/files/select-file/select-file.component', './forms/forms.component', './shared/components/forms/add-form/add-form.component', './shared/components/forms/edit-form/edit-form.component', './shared/components/forms/remove-form/remove-form.component', './shared/components/forms/add-form-field/add-form-field.component', './shared/components/forms/edit-form-field/edit-form-field.component', './shared/components/forms/remove-form-field/remove-form-field.component', './galleries/galleries.component', './shared/components/galleries/add-gallery/add-gallery.component', './shared/components/galleries/edit-gallery/edit-gallery.component', './shared/components/galleries/remove-gallery/remove-gallery.component', './shared/components/galleries/edit-caption/edit-caption.component', './shared/components/galleries/remove-gallery-image/remove-gallery-image.component', './menus/menus.component', './shared/components/menus/add-menu/add-menu.component', './shared/components/menus/edit-menu/edit-menu.component', './shared/components/menus/remove-menu/remove-menu.component', './shared/components/menus/add-menu-item/add-menu-item.component', './shared/components/menus/edit-menu-item/edit-menu-item.component', './shared/components/menus/remove-menu-item/remove-menu-item.component', './pages/pages.component', './shared/components/pages/add-page/add-page.component', './shared/components/pages/page-settings/page-settings.component', './shared/components/pages/remove-page/remove-page.component', './settings/settings.component', './submissions/submissions.component', './shared/components/submissions/remove-submission/remove-submission.component', './shared/components/submissions/view-submission/view-submission.component', './users/users.component', './shared/components/users/add-user/add-user.component', './shared/components/users/edit-user/edit-user.component', './shared/components/users/remove-user/remove-user.component', '@angular/http', './app.routes', 'ng2-translate/ng2-translate', './shared/pipes/time-ago.pipe'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, platform_browser_1, forms_1, router_1, app_component_1, drawer_component_1, dropzone_component_1, login_component_1, forgot_component_1, reset_component_1, create_component_1, developer_component_1, code_component_1, edit_component_1, files_component_1, remove_file_component_1, select_file_component_1, forms_component_1, add_form_component_1, edit_form_component_1, remove_form_component_1, add_form_field_component_1, edit_form_field_component_1, remove_form_field_component_1, galleries_component_1, add_gallery_component_1, edit_gallery_component_1, remove_gallery_component_1, edit_caption_component_1, remove_gallery_image_component_1, menus_component_1, add_menu_component_1, edit_menu_component_1, remove_menu_component_1, add_menu_item_component_1, edit_menu_item_component_1, remove_menu_item_component_1, pages_component_1, add_page_component_1, page_settings_component_1, remove_page_component_1, settings_component_1, submissions_component_1, remove_submission_component_1, view_submission_component_1, users_component_1, add_user_component_1, edit_user_component_1, remove_user_component_1, http_1, app_routes_1, ng2_translate_1, time_ago_pipe_1;
    var AppModule;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (forms_1_1) {
                forms_1 = forms_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            },
            function (drawer_component_1_1) {
                drawer_component_1 = drawer_component_1_1;
            },
            function (dropzone_component_1_1) {
                dropzone_component_1 = dropzone_component_1_1;
            },
            function (login_component_1_1) {
                login_component_1 = login_component_1_1;
            },
            function (forgot_component_1_1) {
                forgot_component_1 = forgot_component_1_1;
            },
            function (reset_component_1_1) {
                reset_component_1 = reset_component_1_1;
            },
            function (create_component_1_1) {
                create_component_1 = create_component_1_1;
            },
            function (developer_component_1_1) {
                developer_component_1 = developer_component_1_1;
            },
            function (code_component_1_1) {
                code_component_1 = code_component_1_1;
            },
            function (edit_component_1_1) {
                edit_component_1 = edit_component_1_1;
            },
            function (files_component_1_1) {
                files_component_1 = files_component_1_1;
            },
            function (remove_file_component_1_1) {
                remove_file_component_1 = remove_file_component_1_1;
            },
            function (select_file_component_1_1) {
                select_file_component_1 = select_file_component_1_1;
            },
            function (forms_component_1_1) {
                forms_component_1 = forms_component_1_1;
            },
            function (add_form_component_1_1) {
                add_form_component_1 = add_form_component_1_1;
            },
            function (edit_form_component_1_1) {
                edit_form_component_1 = edit_form_component_1_1;
            },
            function (remove_form_component_1_1) {
                remove_form_component_1 = remove_form_component_1_1;
            },
            function (add_form_field_component_1_1) {
                add_form_field_component_1 = add_form_field_component_1_1;
            },
            function (edit_form_field_component_1_1) {
                edit_form_field_component_1 = edit_form_field_component_1_1;
            },
            function (remove_form_field_component_1_1) {
                remove_form_field_component_1 = remove_form_field_component_1_1;
            },
            function (galleries_component_1_1) {
                galleries_component_1 = galleries_component_1_1;
            },
            function (add_gallery_component_1_1) {
                add_gallery_component_1 = add_gallery_component_1_1;
            },
            function (edit_gallery_component_1_1) {
                edit_gallery_component_1 = edit_gallery_component_1_1;
            },
            function (remove_gallery_component_1_1) {
                remove_gallery_component_1 = remove_gallery_component_1_1;
            },
            function (edit_caption_component_1_1) {
                edit_caption_component_1 = edit_caption_component_1_1;
            },
            function (remove_gallery_image_component_1_1) {
                remove_gallery_image_component_1 = remove_gallery_image_component_1_1;
            },
            function (menus_component_1_1) {
                menus_component_1 = menus_component_1_1;
            },
            function (add_menu_component_1_1) {
                add_menu_component_1 = add_menu_component_1_1;
            },
            function (edit_menu_component_1_1) {
                edit_menu_component_1 = edit_menu_component_1_1;
            },
            function (remove_menu_component_1_1) {
                remove_menu_component_1 = remove_menu_component_1_1;
            },
            function (add_menu_item_component_1_1) {
                add_menu_item_component_1 = add_menu_item_component_1_1;
            },
            function (edit_menu_item_component_1_1) {
                edit_menu_item_component_1 = edit_menu_item_component_1_1;
            },
            function (remove_menu_item_component_1_1) {
                remove_menu_item_component_1 = remove_menu_item_component_1_1;
            },
            function (pages_component_1_1) {
                pages_component_1 = pages_component_1_1;
            },
            function (add_page_component_1_1) {
                add_page_component_1 = add_page_component_1_1;
            },
            function (page_settings_component_1_1) {
                page_settings_component_1 = page_settings_component_1_1;
            },
            function (remove_page_component_1_1) {
                remove_page_component_1 = remove_page_component_1_1;
            },
            function (settings_component_1_1) {
                settings_component_1 = settings_component_1_1;
            },
            function (submissions_component_1_1) {
                submissions_component_1 = submissions_component_1_1;
            },
            function (remove_submission_component_1_1) {
                remove_submission_component_1 = remove_submission_component_1_1;
            },
            function (view_submission_component_1_1) {
                view_submission_component_1 = view_submission_component_1_1;
            },
            function (users_component_1_1) {
                users_component_1 = users_component_1_1;
            },
            function (add_user_component_1_1) {
                add_user_component_1 = add_user_component_1_1;
            },
            function (edit_user_component_1_1) {
                edit_user_component_1 = edit_user_component_1_1;
            },
            function (remove_user_component_1_1) {
                remove_user_component_1 = remove_user_component_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (app_routes_1_1) {
                app_routes_1 = app_routes_1_1;
            },
            function (ng2_translate_1_1) {
                ng2_translate_1 = ng2_translate_1_1;
            },
            function (time_ago_pipe_1_1) {
                time_ago_pipe_1 = time_ago_pipe_1_1;
            }],
        execute: function() {
            AppModule = (function () {
                function AppModule() {
                }
                AppModule = __decorate([
                    core_1.NgModule({
                        declarations: [
                            app_component_1.AppComponent,
                            login_component_1.LoginComponent,
                            forgot_component_1.ForgotComponent,
                            reset_component_1.ResetComponent,
                            create_component_1.CreateComponent,
                            drawer_component_1.DrawerComponent, dropzone_component_1.DropzoneComponent,
                            edit_component_1.EditComponent, developer_component_1.DeveloperComponent, code_component_1.CodeComponent,
                            files_component_1.FilesComponent, remove_file_component_1.RemoveFileComponent, select_file_component_1.SelectFileComponent,
                            forms_component_1.FormsComponent, add_form_component_1.AddFormComponent, edit_form_component_1.EditFormComponent, remove_form_component_1.RemoveFormComponent, add_form_field_component_1.AddFormFieldComponent, edit_form_field_component_1.EditFormFieldComponent, remove_form_field_component_1.RemoveFormFieldComponent,
                            galleries_component_1.GalleriesComponent, add_gallery_component_1.AddGalleryComponent, edit_gallery_component_1.EditGalleryComponent, remove_gallery_component_1.RemoveGalleryComponent, edit_caption_component_1.EditCaptionComponent, remove_gallery_image_component_1.RemoveGalleryImageComponent,
                            menus_component_1.MenusComponent, add_menu_component_1.AddMenuComponent, edit_menu_component_1.EditMenuComponent, remove_menu_component_1.RemoveMenuComponent, add_menu_item_component_1.AddMenuItemComponent, edit_menu_item_component_1.EditMenuItemComponent, remove_menu_item_component_1.RemoveMenuItemComponent,
                            pages_component_1.PagesComponent, add_page_component_1.AddPageComponent, page_settings_component_1.PageSettingsComponent, remove_page_component_1.RemovePageComponent,
                            settings_component_1.SettingsComponent,
                            submissions_component_1.SubmissionsComponent, remove_submission_component_1.RemoveSubmissionComponent, view_submission_component_1.ViewSubmissionComponent,
                            users_component_1.UsersComponent, add_user_component_1.AddUserComponent, edit_user_component_1.EditUserComponent, remove_user_component_1.RemoveUserComponent,
                            time_ago_pipe_1.TimeAgoPipe],
                        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule, app_routes_1.routing, http_1.HttpModule, ng2_translate_1.TranslateModule.forRoot()],
                        bootstrap: [app_component_1.AppComponent],
                        providers: []
                    }), 
                    __metadata('design:paramtypes', [])
                ], AppModule);
                return AppModule;
            }());
            exports_1("AppModule", AppModule);
        }
    }
});

//# sourceMappingURL=app.module.js.map
