System.register(['@angular/core', '@angular/router', '../shared/services/menu.service', '../shared/services/menu-item.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, menu_service_1, menu_item_service_1;
    var MenusComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (menu_service_1_1) {
                menu_service_1 = menu_service_1_1;
            },
            function (menu_item_service_1_1) {
                menu_item_service_1 = menu_item_service_1_1;
            }],
        execute: function() {
            MenusComponent = (function () {
                function MenusComponent(_menuService, _menuItemService, _router) {
                    this._menuService = _menuService;
                    this._menuItemService = _menuItemService;
                    this._router = _router;
                }
                /**
                 * Init
                 *
                 */
                MenusComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.addVisible = false;
                    this.editVisible = false;
                    this.removeVisible = false;
                    this.addItemVisible = false;
                    this.editItemVisible = false;
                    this.removeItemVisible = false;
                    this.drawerVisible = false;
                    this.overflowVisible = false;
                    this.menus = [];
                    this.items = [];
                    this.list();
                };
                /**
                 * Updates the list
                 */
                MenusComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._menuService.list()
                        .subscribe(function (data) { _this.menus = data; _this.success(); }, function (error) { _this.failure(error); });
                };
                /**
                 * handles the list successfully updated
                 */
                MenusComponent.prototype.success = function () {
                    var x, flag = false;
                    // check if selected menu is set
                    if (this.menus.length > 0 && this.menus != undefined) {
                        if (this.selectedMenu !== undefined && this.selectedMenu !== null) {
                            for (x = 0; x < this.menus.length; x++) {
                                if (this.menus[x].id === this.selectedMenu.id) {
                                    flag = true;
                                }
                            }
                        }
                        // check if id is in array
                        if (flag === false) {
                            this.selectedMenu = this.menus[0];
                        }
                    }
                    // update items
                    if (this.selectedMenu !== null) {
                        this.listItems();
                    }
                };
                /**
                 * list items in the menu
                 */
                MenusComponent.prototype.listItems = function () {
                    var _this = this;
                    this._menuItemService.list(this.selectedMenu.id)
                        .subscribe(function (data) { _this.items = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets screen
                 */
                MenusComponent.prototype.reset = function () {
                    this.addVisible = false;
                    this.editVisible = false;
                    this.removeVisible = false;
                    this.addItemVisible = false;
                    this.editItemVisible = false;
                    this.removeItemVisible = false;
                    this.drawerVisible = false;
                    this.overflowVisible = false;
                };
                /**
                 * Sets the menu to active
                 *
                 * @param {Menu} menu
                 */
                MenusComponent.prototype.setActive = function (menu) {
                    this.selectedMenu = menu;
                    this.listItems();
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {MenuItem} item
                 */
                MenusComponent.prototype.setItemActive = function (item) {
                    this.selectedItem = item;
                    this.selectedIndex = this.items.indexOf(item);
                };
                /**
                 * Shows the drawer
                 */
                MenusComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the overflow menu
                 */
                MenusComponent.prototype.toggleOverflow = function () {
                    this.overflowVisible = !this.overflowVisible;
                };
                /**
                 * Shows the add dialog
                 */
                MenusComponent.prototype.showAdd = function () {
                    this.addVisible = true;
                };
                /**
                 * Shows the edit dialog
                 */
                MenusComponent.prototype.showEdit = function () {
                    this.editVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {menu} menu
                 */
                MenusComponent.prototype.showRemove = function (menu) {
                    this.removeVisible = true;
                    this.menu = menu;
                };
                /**
                 * Shows the add dialog
                 */
                MenusComponent.prototype.showAddItem = function () {
                    this.addItemVisible = true;
                };
                /**
                 * Shows the edit dialog
                 */
                MenusComponent.prototype.showEditItem = function () {
                    this.editItemVisible = true;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {menu} menu
                 */
                MenusComponent.prototype.showRemoveItem = function (menu) {
                    this.removeItemVisible = true;
                };
                /**
                 * Move the item up
                 *
                 * @param {item} menu
                 */
                MenusComponent.prototype.moveItemUp = function (item) {
                    var i = this.items.indexOf(item);
                    if (i != 0) {
                        this.items.splice(i, 1);
                        this.items.splice(i - 1, 0, item);
                    }
                    this.updateOrder();
                };
                /**
                 * Move the item down
                 *
                 * @param {item} menu
                 */
                MenusComponent.prototype.moveItemDown = function (item) {
                    var i = this.items.indexOf(item);
                    if (i != (this.items.length - 1)) {
                        this.items.splice(i, 1);
                        this.items.splice(i + 1, 0, item);
                    }
                    this.updateOrder();
                };
                /**
                 * Updates the order of the menu items
                 *
                 */
                MenusComponent.prototype.updateOrder = function () {
                    var _this = this;
                    this._menuItemService.updateOrder(this.selectedMenu.id, this.items)
                        .subscribe(function (data) { }, function (error) { _this.failure(error); });
                };
                /**
                 * handles error
                 */
                MenusComponent.prototype.failure = function (obj) {
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                MenusComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-menus',
                        template: "<menu class=\"app-menu\" [class.noborder]=\"menus.length !== 0\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Menus' | translate }}</h1>      <button class=\"app-add position-2\" (click)=\"showAddItem()\" *ngIf=\"menus.length !== 0\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z\"></path></g></svg></button>      <button class=\"app-overflow\" (click)=\"toggleOverflow()\" *ngIf=\"selectedMenu !== undefined\"><svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"/><path d=\"M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z\"/></svg></button>  </menu>  <section class=\"app-main\">    <nav class=\"app-selector\">     <ul>       <li *ngFor=\"let menu of menus\" [class.selected]=\"menu.id === selectedMenu.id\" (click)=\"setActive(menu)\">         <a>{{menu.name}}</a>       </li>     </ul>   </nav>     <div id=\"items-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let item of items\" (click)=\"setItemActive(item)\" [class.selected]=\"item === selectedItem\">       <h2><span class=\"primary\">{{ item.html }}</span></h2>       <small>{{ item.url }}</small>       <div class=\"app-list-actions\">           <span class=\"app-list-alternate-actions\">             <a (click)=\"moveItemDown(item)\">{{ 'Move Down' | translate }}</a>             <a (click)=\"moveItemUp(item)\">{{ 'Move Up' | translate }}</a>           </span>           <a (click)=\"showRemoveItem(item)\">{{ 'Remove' | translate }}</a>           <a class=\"primary\" (click)=\"showEditItem(item)\">{{ 'Edit' | translate }}</a>       </div>     </div>   </div>    <p class=\"no-list-items\" *ngIf=\"items.length === 0\">     {{ 'Nothing here yet' | translate }}     <a (click)=\"showAddItem()\" *ngIf=\"menus.length !== 0 && items.length === 0\">{{ 'Add Menu Item' | translate }}</a>     <a (click)=\"showAdd()\" *ngIf=\"menus.length === 0\">{{ 'Add Menu' | translate }}</a>   </p>  </section>  <respond-add-menu [visible]=\"addVisible\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-menu>  <respond-edit-menu [visible]=\"editVisible\" [menu]=\"selectedMenu\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-edit-menu>  <respond-remove-menu [visible]=\"removeVisible\" [menu]=\"selectedMenu\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-menu>  <respond-add-menu-item [visible]=\"addItemVisible\" [menu]=\"selectedMenu\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-add-menu-item>  <respond-edit-menu-item [visible]=\"editItemVisible\" [menu]=\"selectedMenu\" [item]=\"selectedItem\" [index]=\"selectedIndex\" (onCancel)=\"reset($event)\" (onAdd)=\"list($event)\" (onError)=\"failure($event)\"></respond-edit-menu-item>  <respond-remove-menu-item [visible]=\"removeItemVisible\" [menu]=\"selectedMenu\" [item]=\"selectedItem\" [index]=\"selectedIndex\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-menu-item>  <respond-drawer active=\"menus\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>  <nav class=\"app-overflow\" [class.visible]=\"overflowVisible === true\">    <ul>     <li class=\"app-overflow-title\"><span>{{ 'Additional Options' | translate }}</span></li>     <li><a (click)=\"showAdd()\">{{ 'Add Menu' | translate }}</a></li>     <li><a (click)=\"showEdit()\">{{ 'Edit Menu' | translate }}</a></li>     <li><a (click)=\"showRemove()\">{{ 'Remove Menu' | translate }}</a></li>   </ul>  </nav>",
                        providers: [menu_service_1.MenuService, menu_item_service_1.MenuItemService],
                    }), 
                    __metadata('design:paramtypes', [menu_service_1.MenuService, menu_item_service_1.MenuItemService, router_1.Router])
                ], MenusComponent);
                return MenusComponent;
            }());
            exports_1("MenusComponent", MenusComponent);
        }
    }
});

//# sourceMappingURL=menus.component.js.map
