System.register(['@angular/core', '@angular/router', '../shared/services/file.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, file_service_1;
    var FilesComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (file_service_1_1) {
                file_service_1 = file_service_1_1;
            }],
        execute: function() {
            FilesComponent = (function () {
                function FilesComponent(_fileService, _router) {
                    this._fileService = _fileService;
                    this._router = _router;
                }
                /**
                 * Init files
                 *
                 */
                FilesComponent.prototype.ngOnInit = function () {
                    this.id = localStorage.getItem('respond.siteId');
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.file = {};
                    this.files = [];
                    // list files
                    this.list();
                };
                /**
                 * Updates the list
                 */
                FilesComponent.prototype.list = function () {
                    var _this = this;
                    this.reset();
                    this._fileService.list()
                        .subscribe(function (data) { _this.files = data; }, function (error) { _this.failure(error); });
                };
                /**
                 * Resets an modal booleans
                 */
                FilesComponent.prototype.reset = function () {
                    this.removeVisible = false;
                    this.drawerVisible = false;
                    this.file = {};
                };
                /**
                 * Sets the list item to active
                 *
                 * @param {File} file
                 */
                FilesComponent.prototype.setActive = function (file) {
                    this.selectedFile = file;
                };
                /**
                 * Shows the drawer
                 */
                FilesComponent.prototype.toggleDrawer = function () {
                    this.drawerVisible = !this.drawerVisible;
                };
                /**
                 * Shows the remove dialog
                 *
                 * @param {File} file
                 */
                FilesComponent.prototype.showRemove = function (file) {
                    this.removeVisible = true;
                    this.file = file;
                };
                /**
                 * handles error
                 */
                FilesComponent.prototype.failure = function (obj) {
                    toast.show('failure');
                    if (obj.status == 401) {
                        this._router.navigate(['/login', this.id]);
                    }
                };
                FilesComponent = __decorate([
                    core_1.Component({
                        selector: 'respond-files',
                        moduleId: __moduleName,
                        template: "<menu class=\"app-menu\">      <button class=\"app-more\" (click)=\"toggleDrawer()\"><svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\" preserveAspectRatio=\"xMidYMid meet\"><g><path d=\"M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z\"></path></g></svg></button>      <h1>{{ 'Files' | translate }}</h1>  </menu>  <section class=\"app-main\">    <respond-dropzone (onAdd)=\"list($event)\"></respond-dropzone>    <div id=\"files-list\" class=\"app-list\">     <div class=\"app-list-item\" *ngFor=\"let  file of files\" (click)=\"setActive(file)\" [class.selected]=\"file === selectedFile\" [class.image]=\"file.thumb !== ''\">       <h2><span class=\"primary\">{{ file.name }}</span><span class=\"secondary\">{{ file.size }} MB</span></h2>       <img *ngIf=\"file.thumb !== ''\" class=\"image\" src=\"{{file.thumb}}\">       <small>/files/{{ file.name }}</small>       <div class=\"app-list-actions\">           <a (click)=\"showRemove(file)\">Remove</a>       </div>     </div>   </div>    <p class=\"no-list-items\" *ngIf=\"files.length === 0\">{{ 'Nothing here yet' | translate }}</p>  </section>  <respond-remove-file [visible]=\"removeVisible\" [file]=\"file\" (onCancel)=\"reset($event)\" (onUpdate)=\"list($event)\" (onError)=\"failure($event)\"></respond-remove-file>  <respond-drawer active=\"files\" [visible]=\"drawerVisible\" (onHide)=\"reset($event)\"></respond-drawer>",
                        providers: [file_service_1.FileService]
                    }), 
                    __metadata('design:paramtypes', [file_service_1.FileService, router_1.Router])
                ], FilesComponent);
                return FilesComponent;
            }());
            exports_1("FilesComponent", FilesComponent);
        }
    }
});

//# sourceMappingURL=files.component.js.map
