/// <reference path="main/ambient/es6-shim/index.d.ts" />
/// <reference path="main/definitions/moment/index.d.ts" />
